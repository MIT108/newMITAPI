<?php

use App\Models\Role;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('roles', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->timestamps();
        });
        Role::create([
            'name'=>'Super Admin'
        ]);
        Role::create([
            'name'=>'Admin'
        ]);
        Role::create([
            'name'=>'School'
        ]);
        Role::create([
            'name'=>'Teacher'
        ]);
        Role::create([
            'name'=>'Student'
        ]);
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('roles');
    }
};
